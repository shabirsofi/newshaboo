#include <stdio.h>

//Write a Program which perform traversing operation.
#include <stdio.h>
void main()
{
    int LA[] = {2,4,6,8,9};
    int i, n = 5;
    
    printf("The array elements are:\n");
    
    for(i = 0; i < n; i++)
    {
        printf("LA[%d] = %d \n", i, LA[i]);
    }
}
